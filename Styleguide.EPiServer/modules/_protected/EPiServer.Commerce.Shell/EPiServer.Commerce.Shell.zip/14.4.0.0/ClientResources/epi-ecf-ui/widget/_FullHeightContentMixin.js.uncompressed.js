﻿define("epi-ecf-ui/widget/_FullHeightContentMixin", [
    // dojo
    "dojo/_base/declare",
    "dojo/_base/window",
    "dojo/dom-geometry",
    "dojo/dom-style"
], function (
    // dojo
    declare,
    window,
    domGeometry,
    domStyle
) {
    return declare(null, {

        _setHeight: function (targetDomNode) {
            var domNodeTop = domGeometry.position(targetDomNode).y;
            var widgetPos = domGeometry.position(this.domNode);
            var domNodeHeight = widgetPos.y + widgetPos.h - domNodeTop;
            domStyle.set(targetDomNode, "height", domNodeHeight + "px");
        }

    });
});