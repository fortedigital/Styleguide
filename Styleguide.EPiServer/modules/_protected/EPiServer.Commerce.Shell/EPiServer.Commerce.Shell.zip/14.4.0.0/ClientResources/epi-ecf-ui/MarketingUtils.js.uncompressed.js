define("epi-ecf-ui/MarketingUtils", [
    "epi/shell/TypeDescriptorManager"
],

function (
    TypeDescriptorManager
) {
    var marketingUtils = {
        // summary:
        //    This class contains utilities for working with marketing objects
        //    (campaigns, promotions)
        // tags:
        //    public static

        // status: Object
        //      Statuses used on marketing objects
        status : {
            // Note: These should match EPiServer.Commerce.Shell.Rest.Models.CampaignItemStatus
            notSet: 0,
            active: 1,
            pending : 2,
            expired: 3,
            inactive: 4
        },

        // contentTypeIdentifier: Object
        //      Type identifiers for marketing content types
        contentTypeIdentifier: {
            campaignFolder: "episerver.commerce.marketing.salescampaignfolder",
            salesCampaign: "episerver.commerce.marketing.salescampaign",
            promotionData: "episerver.commerce.marketing.promotiondata",
            orderPromotion:"episerver.commerce.marketing.orderpromotion",
            entryPromotion: "episerver.commerce.marketing.entrypromotion",
            shippingPromotion: "episerver.commerce.marketing.shippingpromotion"
        },

        groupIcons: {
            discounttype: "epi-objectIcon"
        },       

        facetItemIcons: {
            order: "epi-iconObjectCart",
            lineitem: "epi-iconObjectItem",
            shipping: "epi-iconObjectTruck"
        },

        getItemIconClass: function (groupId, itemId) {
            if (itemId === "")
            {
                return "";
            }
            var groupIcon = this.groupIcons[groupId.toLowerCase()] || "";
            var itemIcon = this.facetItemIcons[itemId.toLowerCase()] || "";
            return groupIcon + " " + itemIcon;
        },

        isSalesCampaign: function (typeIdentifier) {
            return this._isBaseTypeIdentifier(typeIdentifier, this.contentTypeIdentifier.salesCampaign);
        },

        isPromotionData: function (typeIdentifier) {
            return this._isBaseTypeIdentifier(typeIdentifier, this.contentTypeIdentifier.promotionData);
        },

        isEntryPromotion: function (typeIdentifier) {
            return this._isBaseTypeIdentifier(typeIdentifier, this.contentTypeIdentifier.entryPromotion);
        },

        isOrderPromotion: function (typeIdentifier) {
            return this._isBaseTypeIdentifier(typeIdentifier, this.contentTypeIdentifier.orderPromotion);
        },

        isShippingPromotion: function (typeIdentifier) {
            return this._isBaseTypeIdentifier(typeIdentifier, this.contentTypeIdentifier.shippingPromotion);
        },

        _isBaseTypeIdentifier: function (childType, parentType) {
            return TypeDescriptorManager.isBaseTypeIdentifier(childType, parentType);
        },

        getStatusString: function(statusValue){
            switch (statusValue) {
                case this.status.pending:
                    return "pending";
                case this.status.active:
                    return "active";
                case this.status.suspended:
                    return "suspended";
                case this.status.expired:
                    return "expired";
                case this.status.deleted:
                    return "deleted";
                default:
                    return "inactive";
            }
        }
    };

    return marketingUtils;
});